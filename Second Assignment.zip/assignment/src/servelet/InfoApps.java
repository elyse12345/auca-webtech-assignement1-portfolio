package servelet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/InfoApps")
public class InfoApps extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public InfoApps() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Simply forward to the form page (JSP or HTML)
        RequestDispatcher dispatcher = request.getRequestDispatcher("index.html"); 
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Read form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        int age = Integer.parseInt(request.getParameter("age"));
        double num1 = Double.parseDouble(request.getParameter("num1"));
        double num2 = Double.parseDouble(request.getParameter("num2"));
        String operation = request.getParameter("operation");

        // Determine Adult/Minor
        String ageStatus = (age >= 18) ? "Adult" : "Minor";

        // Perform calculation
        double result = 0;
        switch (operation) {
            case "add": result = num1 + num2; break;
            case "subtract": result = num1 - num2; break;
            case "multiply": result = num1 * num2; break;
            case "divide": 
                if (num2 != 0) {
                    result = num1 / num2;
                } else {
                    result = Double.NaN; // handle division by zero
                }
                break;
        }

        // Optional message
        String bigNumberMsg = (result > 100) ? "Big number!" : "";

        // Set attributes to pass to JSP
        request.setAttribute("firstName", firstName);
        request.setAttribute("lastName", lastName);
        request.setAttribute("age", age);
        request.setAttribute("ageStatus", ageStatus);
        request.setAttribute("num1", num1);
        request.setAttribute("num2", num2);
        request.setAttribute("operation", operation);
        request.setAttribute("result", result);
        request.setAttribute("bigNumberMsg", bigNumberMsg);

        // Forward to JSP page to display results
        RequestDispatcher dispatcher = request.getRequestDispatcher("result.jsp");
        dispatcher.forward(request, response);
    }

}
