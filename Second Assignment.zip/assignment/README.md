# Web Technology Assignement 2


## Client

![Client](Picture/client.JPG)



## Output

![Output](Picture/output.JPG)

